<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "bookings";
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection Failed:" . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST["id"];
    $name = $_POST["name"];
    $email = $_POST["email"];
    $vaccine = $_POST["vaccine"];
    $date = $_POST["date"];
    $hospital = $_POST["hospital"];

    // Prepare and execute the database insertion
    $sql = "INSERT INTO `booking`(`id`, `name`, `email`, `vaccine`, `date`, `hospital`)
            VALUES ('$id', '$name', '$email', '$vaccine', '$date', '$hospital')";

    if ($conn->query($sql) === TRUE) {
        echo "Booking Successful";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Vaccination Appointment Form</title>
  <link rel="stylesheet" href="style.css">
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins&display=swap');
    body, html {
        height: 100%;
        margin: 0;
        font-family: 'Poppins', sans-serif;
    }
    .background {
        background-color: #f0f0f0;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .booking-form {
        background-color: rgba(255, 255, 255, 0.9);
        padding: 20px;
        border-radius: 10px;
        max-width: 400px;
        width: 100%;
        margin: 0 auto;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }
    .booking-form h2 {
        text-align: center;
        margin-bottom: 20px;
    }
    .booking-form form {
        display: flex;
        flex-direction: column;
    }
    .booking-form input, .booking-form select {
        padding: 8px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        width: calc(100% - 16px);
        margin: 0 auto 10px auto;
    }
    .booking-form button {
        padding: 10px;
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }
    .booking-form button:hover {
        background-color: #45a049;
    }
    @media (max-width: 480px) {
        .booking-form {
            max-width: 90%;
            padding: 15px;
        }
        .booking-form h2 {
            font-size: 18px;
            margin-bottom: 15px;
        }
        .booking-form input, .booking-form select {
            padding: 6px;
            width: calc(100% - 12px);
        }
        .booking-form button {
            padding: 8px;
        }
    }
  </style>
</head>
<body>
<div class="background">
    <div class="booking-form">
        <h2>Vaccination Appointment Form</h2>
        <form action="index.php" method="post">
            <label for="id">ID:</label>
            <input type="text" name="id" id="id" required>

            <label for="name">Name:</label>
            <input type="text" name="name" id="name" required>

            <label for="email">Email:</label>
            <input type="email" name="email" id="email" required>

            <label for="vaccine">Vaccine:</label>
            <select name="vaccine" id="vaccine" required>
                <option value="Pfizer-BioNTech">Pfizer-BioNTech</option>
                <option value="Moderna">Moderna</option>
                <option value="Johnson & Johnson">Johnson & Johnson</option>
                <option value="AstraZeneca">AstraZeneca</option>
                <option value="Sinopharm">Sinopharm</option>
                <option value="Sinovac">Sinovac</option>
            </select>

            <label for="date">Date:</label>
            <input type="date" name="date" id="date" required>

            <label for="hospital">Hospital:</label>
            <input type="text" name="hospital" id="hospital" required>

            <button type="submit">Book Now</button>
        </form>
    </div>
</div>
</body>
</html>
