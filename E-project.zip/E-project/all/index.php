<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        :root {
            --sidebar-bg: #79a9d1;
            --sidebar-hover-bg: #add8e6;
            --content-bg: #fff;
            --text-color: #333;
            --secondary-text-color: #555;
            --link-color: #000;
            --border-color: #ccc;
        }

        .container {
            display: flex;
            flex-direction: column;
            max-width: 1200px;
            margin: 50px auto;
            position: relative;
        }

        nav {
            width: 250px;
            background-color: var(--sidebar-bg);
            padding: 20px;
            box-sizing: border-box;
            position: fixed;
            height: 100%;
            overflow-y: auto;
            top: 0;
            left: 0;
            z-index: 1;
        }

        .logo {
            text-align: center;
            margin-bottom: 20px;
        }

        .logo img {
            max-width: 100%;
            height: auto;
        }

        nav h2 {
            color: #fff;
            font-size: 1.5rem;
            margin-bottom: 10px;
        }

        nav ul {
            list-style-type: none;
            padding: 0;
        }

        nav ul li {
            margin-bottom: 10px;
        }

        nav ul li a {
            color: var(--link-color);
            text-decoration: none;
            display: block;
            padding: 10px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        nav ul li a:hover {
            background-color: var(--sidebar-hover-bg);
        }

        .content {
            flex: 1;
            margin-left: 250px;
            padding: 20px;
            background-color: var(--content-bg);
            box-sizing: border-box;
            transition: margin-left 0.3s ease;
        }

        .content h1,
        .content h2,
        .content p {
            color: var(--text-color);
        }

        .content h2 {
            color: var(--secondary-text-color);
        }

        .content p {
            line-height: 1.6;
        }

        .top-head {
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-bottom: 20px;
        }

        .top-head .login-btns,
        .top-head .datesearch-form {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .top-head .login-btns {
            justify-content: flex-start;
        }

        .top-head .datesearch-form {
            justify-content: space-between;
        }

        .datesearch-form h2 {
            font-size: 24px;
            margin: 0;
        }

        .admin-search-date {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            flex-grow: 1;
        }

        .admin-search-date input[type="search"] {
            border: 2px solid var(--border-color);
            font-size: 16px;
            padding: 7px 12px;
            border-radius: 20px;
        }

        .admin-search-date label {
            font-size: 16px;
            font-weight: 600;
            margin-right: 10px;
        }

        .search-barr {
            position: relative;
            margin-left: 10px;
        }

        .search-barr button {
            position: absolute;
            top: 50%;
            right: 5px;
            transform: translateY(-50%);
            font-size: 18px;
            border: none;
            background: transparent;
            color: var(--border-color);
            cursor: pointer;
        }

        .search-barr button:hover {
            color: var(--link-color);
        }

        .datesearch-form form {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-grow: 1;
        }

        .datesearch-form input[type="date"],
        .datesearch-form button {
            width: 150px;
            margin-left: 5px;
        }

        .table-container {
            width: 100%;
            padding: 20px;
            box-sizing: border-box;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table th,
        table td {
            border: 1px solid var(--border-color);
            padding: 8px;
            text-align: left;
        }

        table th {
            background-color: #f0f0f0;
        }

        .btn-sm {
            padding: 5px 10px;
            font-size: 14px;
        }

        @media only screen and (max-width: 768px) {
            .container {
                margin-top: 80px;
            }

            nav {
                position: static;
                width: 100%;
                margin-bottom: 20px;
            }

            .content {
                margin-left: 0;
            }

            .top-head {
                flex-direction: column;
            }

            .top-head .datesearch-form {
                flex-direction: column;
                gap: 10px;
            }

            .admin-search-date {
                justify-content: center;
            }

            .datesearch-form input[type="date"],
            .datesearch-form button {
                margin-left: 0;
                width: 100%;
            }
        }
    </style>
</head>

<body>

    <!-- Sidebar -->
    <nav>
        <div class="logo">
            <img src="logo.png" alt="Logo">
        </div>
        <h2>Menu</h2>
        <ul>
            <li><a href="#home">Home</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="#contact">Contact</a></li>
        </ul>
    </nav>
    <!-- End Sidebar -->

    <!-- Content -->
    <div class="content">
        <div class="top-head">
            <div class="login-btns">
                <a href="add-new.php" class="btn btn-dark btn-sm">Add New</a>
                <a href="logout.php" class="btn btn-dark btn-sm">Logout</a>
            </div>
            <div class="datesearch-form">
                <h2>Hospital Details</h2>
                <div class="admin-search-date">
                    <label for="query">Search:</label>
                    <span class="search-barr">
                        <input type="search" id="query" name="q"
                            value="<?php if (isset($_GET['q'])) { echo $_GET['q']; } ?>" placeholder="Search...">
                        <button type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
                    </span>
                </div>
            </div>
            <form id="form2" class="datesearch-form" action="" method="GET">
                <label for="startdate">From:</label>
                <input type="date" id="startdate" name="startdate"
                    value="<?php if (isset($_GET['startdate'])) { echo $_GET['startdate']; } ?>" class="small-input">
                <label for="enddate">To:</label>
                <input type="date" id="enddate" name="enddate"
                    value="<?php if (isset($_GET['enddate'])) { echo $_GET['enddate']; } ?>" class="small-input">
                <button type="submit" class="btn btn-primary btn-sm small-input">Filter</button>
            </form>
        </div>

        <div class="table-container">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $servername = "localhost";
                    $username = "root";
                    $password = "";
                    $database = "mystore";

                    // Create Connection
                    $connection = new mysqli($servername, $username, $password, $database);

                    // Check Connection
                    if ($connection->connect_error) {
                        die("Connection failed: " . $connection->connect_error);
                    }

                    // Read all rows from database table
                    $sql = "SELECT * FROM employees";
                    $result = $connection->query($sql);

                    if (!$result) {
                        die("Invalid Query: " . $connection->error);
                    }

                    // Read data from each row
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>
                            <td>" . $row["id"] . "</td>
                            <td>" . $row["first_name"] . "</td>
                            <td>" . $row["last_name"] . "</td>
                            <td>" . $row["email"] . "</td>
                            <td>" . $row["phone"] . "</td>
                            <td>" . $row["address"] . "</td>
                            <td>
                                <a class='btn btn-primary btn-sm' href='update.php?id=" . $row["id"] . "'>Update</a>
                                <a class='btn btn-primary btn-sm' href='delete.php?id=" . $row["id"] . "'>Delete</a>
                            </td>
                        </tr>";
                    }

                    $connection->close();
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <!-- End Content -->

</body>

</html>
